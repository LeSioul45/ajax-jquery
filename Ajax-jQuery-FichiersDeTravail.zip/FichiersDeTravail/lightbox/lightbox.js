
/* Slideshow + Lightbox */

$(document).ready(function() {

	// Redéfinition de styles
	$("#slideshow").css("position","relative");
	$("#slideshow img").css("position","absolute");
	$("#slideshow img:gt(0)").hide();
	
	// Ajout des liens
	$("#slideshow").append("<p><a href=\"#\" class=\"prev\">Précédente</a> | <a href=\"#\" class=\"next\">Suivante</a></p>");
	$("#slideshow p").css("padding-top","340px");
	
	// Clic sur le lien suivant
	$("#slideshow a.next").click(function() {
		var $img_suivante = $("#slideshow img:visible").next("img");
		if($img_suivante.length<1) $img_suivante = $("#slideshow img:first");
		$("#slideshow img:visible").fadeOut();
		$img_suivante.fadeIn();
	});
	
	// Clic sur le lien précédent
	$("#slideshow a.prev").click(function() {
		var $img_precedente = $("#slideshow img:visible").prev("img");
		if($img_precedente.length<1) $img_precedente = $("#slideshow img:last");
		$("#slideshow img:visible").fadeOut();
		$img_precedente.fadeIn();	
	});
	
	// Lightbox
	
	$("#dolightbox").click(openlight);
	
	// Modification dynamique de la page et des styles
	function openlight() {
		$("body").append("<div id=\"zone\"></div>");
		$("body").prepend("<div id=\"cache\"></div>");
		$("#cache").css({
			"width":"100%",
			"height":"100%",
			"background":"black",
			"z-index":"10",
			"position":"absolute",
			"top":"0",
			"left":"0",
			"opacity":0.5
		});
		$("#zone").css({
			"width":"500px",
			"height":"420px",
			"background":"white",
			"z-index":"20",
			"position":"absolute",
			"top":"50%",
			"left":"50%",
			"padding":"10px",
			"margin-left":"-250px",
			"margin-top":"-210px"
		});
		$("#slideshow").after("<span id=\"marquage\"></span>");
		$("#zone").prepend("<p style=\"text-align:right;margin:0\"><a href=\"#\" class=\"close\">Fermer</a></p>");
		$("#zone a").click(closelight);
		$("#slideshow").appendTo("#zone");
	}
	
	// Fermer la lightbox
	function closelight() {
		// On rétablit les éléments à leur position originale dans le flux
		$("#slideshow").appendTo("#marquage");
		$("#zone, #cache").remove();
	}
	

});

