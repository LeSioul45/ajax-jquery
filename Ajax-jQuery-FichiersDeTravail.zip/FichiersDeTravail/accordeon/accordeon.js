
/* Accord�on */

$(document).ready(function() {

	// On masque les paragraphes
	$("#accordeon p").hide();
	
	// On affiche le premier
	$("#accordeon p:first").show();
	
	// On ajoute un �l�ment <a> au sein des titres <h3>
	$("#accordeon h3").wrapInner("<a></a>");
	
	// On lui adjoint un attribut href
	$("#accordeon h3 a").attr("href","#");
	
	// Gestion de l'�v�nement clic sur chacun des liens de l'accord�on
	$("#accordeon h3 a").click(function() {
		// On retrouve le paragraphe suivant le titre cliqu� dans le DOM
		var $p = $(this).parent().next("p");
		// Si le paragraphe n'est pas visible on le d�roule, tout en masquant les autres
		if(!$p.is(":visible")) {
			$("#accordeon p").slideUp();
			$p.slideDown();
		}
	});

});
