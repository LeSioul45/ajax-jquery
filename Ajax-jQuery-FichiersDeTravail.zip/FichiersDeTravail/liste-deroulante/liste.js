
/* Liste d�roulante */

$(document).ready(function() {

	// On masque tous les �l�ments <ul> pr�sents dans #maliste
	$("#maliste ul").hide();
	
	// Gestion du clic sur les liens de premier niveau
	$("#maliste>li>a").click(function() {
		// On 'slide' toute liste suivant l'�l�ment cliqu�
		$(this).next("ul").slideToggle();
	});

});
