
/* Slideshow */

$(document).ready(function() {

	// Redéfinitions de styles et ajout de liens
	$("#slideshow img").css("position","absolute");
	$("#slideshow").css("position","relative");
	$("#slideshow img:gt(0)").hide();
	$("#slideshow").append("<p><a href=\"#\" class=\"prev\">Précédente</a> | <a href=\"#\" class=\"next\">Suivante</a></p>");
	$("#slideshow p").css("padding-top","340px");
	
	// Gestionnaire de clic sur le lien suivant
	$("#slideshow a.next").click(function() {
		var $image_suivante = $("#slideshow img:visible").next("img");
		if($image_suivante.length<1) $image_suivante = $("#slideshow img:first");
		$("#slideshow img:visible").fadeOut();
		$image_suivante.fadeIn();
		return false;
	});

	// Gestionnaire de clic sur le lien précédent
	$("#slideshow a.prev").click(function() {
		var $image_precedente = $("#slideshow img:visible").prev("img");
		if($image_precedente.length<1) $image_precedente = $("#slideshow img:last");
		$("#slideshow img:visible").fadeOut();
		$image_precedente.fadeIn();
		return false;
	});
	
	// Défilement automatique
	function auto() {
		// On déclenche volontairement l'événement "click" sur le lien "a.next"
		$("#slideshow a.next").trigger("click");
	}
	
	// La fonction setInterval nous permet de déclencher la fonction "auto" toutes les 2000 ms
	setInterval(auto,2000);
	
});
