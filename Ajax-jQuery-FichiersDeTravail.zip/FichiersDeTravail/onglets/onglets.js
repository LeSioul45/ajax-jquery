
/* Onglets */

$(document).ready(function() {

	// Conteneur
	$("#onglets").prepend("<div class=\"groupe\"></div>");
	$("#onglets div").css("border-bottom","2px solid #666");
	
	// R�union des onglets
	var $titres = $("#onglets :header");
	$titres.appendTo("#onglets div.groupe");
	
	// Styles des onglets
	$titres.css({
		"display":"inline-block",
		"padding":"0.2em 1em",
		"margin":"0 0.3em",
		"cursor":"pointer",
		"background":"#333"
	});
	
	// On masque tout onglet dont l'index est sup�rieur � 0 (c'est � dire tous sauf le premier)
	$("#onglets p:gt(0)").hide();
	
	// On ajoute une classe sp�cifique au premier titre
	$titres.first().addClass("highlight2");
	
	// Gestion du clic sur les titres
	$titres.click(function() {
		
		// On cache tous les paragraphes
		$("#onglets p").hide();
		
		// On r�cup�re l'index courant
		var i = $(this).index();
		// Pour afficher ensuite le paragraphe �quivalent poss�dant cet index
		$("#onglets p:eq("+i+")").show();
		
		// On retire la classe de mise en valeur sur tous les titres puis on la r�applique sur le titre courant
		$titres.removeClass("highlight2");
		$(this).addClass("highlight2");
	
	});

});
