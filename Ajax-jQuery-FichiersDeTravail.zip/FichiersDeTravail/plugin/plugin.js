
/* Slideshow version plugin */

$.fn.slideshow = function() {

	// Redéfinition de styles et ajout de liens
	$(this).children("img").css("position","absolute");
	$(this).css("position","relative");
	$(this).children("img:gt(0)").hide();
	$(this).append("<p><a href=\"#\" class=\"prev\">Précédente</a> | <a href=\"#\" class=\"next\">Suivante</a></p>");
	$(this).find("p").css("padding-top","340px");
	
	// On mémorise le résultat des sélecteurs jQuery dans deux variables
	var $lien_suivant = $(this).find("p a.next");
	var $lien_precedent = $(this).find("p a.prev");
	
	// Clic sur le lien suivant
	$lien_suivant.click(function() {
		var $slideshowparent = $(this).parents("div:first");
		var $image_suivante = $slideshowparent.children("img:visible").next("img");
		if($image_suivante.length<1) $image_suivante = $slideshowparent.children("img:first");
		$slideshowparent.children("img:visible").fadeOut();
		$image_suivante.fadeIn();
		return false;
	});

	// Clic sur le lien précédent
	$lien_precedent.click(function() {
		var $slideshowparent = $(this).parents("div:first");
		var $image_precedente = $slideshowparent.children("img:visible").prev("img");
		if($image_precedente.length<1) $image_precedente = $slideshowparent.children("img:last");
		$slideshowparent.children("img:visible").fadeOut();
		$image_precedente.fadeIn();
		return false;
	});
	
}

// Lorsque le document est prêt, on initie deux slideshows
$(document).ready(function() {
	$("#photos1").slideshow();
	$("#photos2").slideshow();
});

